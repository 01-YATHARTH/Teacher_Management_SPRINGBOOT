package com.example.teachermanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeachermanagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(TeachermanagementApplication.class, args);
    }
}
